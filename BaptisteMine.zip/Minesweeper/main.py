import gui

def main():
    gui.GameGUI().gameLoop()

main()